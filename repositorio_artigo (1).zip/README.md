# Reprovação no Ensino Fundamental e Abandono no Ensino Médio (2015–2024)

Este repositório contém o artigo, dados e scripts do estudo que analisa a relação entre reprovação no EF e abandono no EM no Brasil (2015–2024).
