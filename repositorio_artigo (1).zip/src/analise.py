# script de análise
